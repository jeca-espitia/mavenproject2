/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {

    Connection con;
    private String DRIVER = "com.mysql.cj.jdbc.Driver"; //  "com.mysql.jdbc.Driver";
    private String username = "root";
    private String password = "1209";
    private String host = "jdbc:mysql://localhost:3306/bd_payasyougo";

    public Connection getConnection() {
        
        try {
            Class.forName(DRIVER);
            con = DriverManager.getConnection(host, username, password);
            JOptionPane.showMessageDialog(null, "CONEXIÓN ÉXITOSA ");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR EN LA CONEXION: " + e);
        }return con;
    }}
    


 
