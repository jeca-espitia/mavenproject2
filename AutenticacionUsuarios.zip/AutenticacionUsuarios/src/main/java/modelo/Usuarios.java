/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Camila Espitia
 */
public class Usuarios {

    int idusuarios;
    String nombre;
    String identificacion;
    String correo;
    String direccion;
    boolean estado;
    boolean rol;
    String contraseña;

    public Usuarios() {
    }

    public Usuarios(int idusuarios, String nombre, String identificacion, String correo, String direccion, boolean estado, boolean rol, String contraseña) {
        this.idusuarios = idusuarios;
        this.nombre = nombre;
        this.identificacion = identificacion;
        this.correo = correo;
        this.direccion = direccion;
        this.estado = estado;
        this.rol = rol;
        this.contraseña = contraseña;
    }

    public int getIdusuarios() {
        return idusuarios;
    }

    public void setIdusuarios(int idusuarios) {
        this.idusuarios = idusuarios;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public boolean isRol() {
        return rol;
    }

    public void setRol(boolean rol) {
        this.rol = rol;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }


    
   

    
    }

 

   
    

