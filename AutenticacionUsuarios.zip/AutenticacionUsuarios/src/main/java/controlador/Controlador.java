/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import modelo.Usuarios;
import modelo.UsuariosDAO;

/**
 *
 * @author Camila Espitia
 */
public class Controlador extends HttpServlet {

    UsuariosDAO dao=new UsuariosDAO();
    Usuarios    p=new Usuarios();
    int r;
   
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String accion=request.getParameter("accion");
        
        HttpSession sesion = request.getSession();
        
        if (accion.equals("Ingresar")){
            String Correo=request.getParameter("txtCorreo");
            String Contraseña=request.getParameter("txtContraseña");
            p.setCorreo(Correo);
            p.setContraseña(Contraseña);
            r=dao.validar(p);
            
            
            JOptionPane.showMessageDialog(null, r);
    
                    
            if (r==1){
                
               // request.getSession().setAttribute("correo", Correo);
                sesion.setAttribute("correo", Correo);
                
                request.getRequestDispatcher("PagUsuario.jsp").forward(request, response);
            }else{
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        }
         
        
        

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
